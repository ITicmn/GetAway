#include <iostream>
#include <math.h>
#include <cmath>
#include <windows.h>
#include "control.cpp"
#include "turtorial.cpp"

using namespace std;

void sets1()
{
    cout<<"            * Control                                                                                 "<<endl;
    cout<<"              Turtorial                                                                               "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;

}

void sets2()
{
    cout<<"              Control                                                                                 "<<endl;
    cout<<"            * Turtorial                                                                               "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;

}

int sets()
{
    se:
    bool S,T;
    S=true;
    system("cls");
    sets1();
    while (1)
    {
        if ((GetKeyState(VK_ESCAPE) & 0x8000))
        {
            Sleep(100);
            system("cls");
            break;
        }
        else if (GetKeyState(VK_SPACE) & 0x8000)
        {
            if (S==true)
            {
                Sleep(100);
                system("cls");
                con();
                goto se;
            }
            else if (T==true)
            {
                Sleep(100);
                system("cls");
                tur1();
                goto se;
            }
        }
        else if (GetKeyState(VK_UP) & 0x8000)
        {
            if (T==true)
            {
                Sleep(100);
                T=false;
                system("cls");
                sets2;
                S=true;
            }
        }
        else if (GetKeyState(VK_DOWN) & 0x8000)
        {
            if (S==true)
            {
                Sleep(100);
                S=false;
                system("cls");
                sets1();
                T=true;
            }
        }
    }
    return 0;
}
