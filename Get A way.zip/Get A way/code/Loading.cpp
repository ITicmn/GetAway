#include <iostream>
#include <math.h>
#include <cmath>
#include <windows.h>

using namespace std;

void Load8()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"            ______      _____    _________                                                            "<<endl;
    cout<<"           |           |             |                                                       ___      "<<endl;
    cout<<"           |    __     |_____        |                                                      |   |     "<<endl;
    cout<<"           |      |    |             |                                                      |   |     "<<endl;
    cout<<"           |______|    |_____        |                                                      |   |     "<<endl;
    cout<<"                                                                                            |   |     "<<endl;
    cout<<"                                 _________                      _________                   |   |     "<<endl;
    cout<<"                                |         |    |     |    |    |         |   |         |    |   |     "<<endl;
    cout<<"                                |_________|    |     |    |    |_________|   |         |    |___|     "<<endl;
    cout<<"                                |         |    |     |    |    |         |   |_________|     ___      "<<endl;
    cout<<"                                |         |    |     |    |    |         |        |         |   |     "<<endl;
    cout<<"                                |         |    |_____|____|    |         |        |         |___|     "<<endl;

}
void Load7()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"            ______      _____    _________                                                            "<<endl;
    cout<<"           |           |             |                                                                "<<endl;
    cout<<"           |    __     |_____        |                                                                "<<endl;
    cout<<"           |      |    |             |                                                                "<<endl;
    cout<<"           |______|    |_____        |                                                                "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                 _________                      _________                             "<<endl;
    cout<<"                                |         |    |     |    |    |         |   |         |              "<<endl;
    cout<<"                                |_________|    |     |    |    |_________|   |         |              "<<endl;
    cout<<"                                |         |    |     |    |    |         |   |_________|              "<<endl;
    cout<<"                                |         |    |     |    |    |         |        |                   "<<endl;
    cout<<"                                |         |    |_____|____|    |         |        |                   "<<endl;

}void Load6()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"            ______      _____    _________                                                            "<<endl;
    cout<<"           |           |             |                                                                "<<endl;
    cout<<"           |    __     |_____        |                                                                "<<endl;
    cout<<"           |      |    |             |                                                                "<<endl;
    cout<<"           |______|    |_____        |                                                                "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                 _________                      _________                             "<<endl;
    cout<<"                                |         |    |     |    |    |         |                            "<<endl;
    cout<<"                                |_________|    |     |    |    |_________|                            "<<endl;
    cout<<"                                |         |    |     |    |    |         |                            "<<endl;
    cout<<"                                |         |    |     |    |    |         |                            "<<endl;
    cout<<"                                |         |    |_____|____|    |         |                            "<<endl;

}void Load5()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"            ______      _____    _________                                                            "<<endl;
    cout<<"           |           |             |                                                                "<<endl;
    cout<<"           |    __     |_____        |                                                                "<<endl;
    cout<<"           |      |    |             |                                                                "<<endl;
    cout<<"           |______|    |_____        |                                                                "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                 _________                                                            "<<endl;
    cout<<"                                |         |    |     |    |                                           "<<endl;
    cout<<"                                |_________|    |     |    |                                           "<<endl;
    cout<<"                                |         |    |     |    |                                           "<<endl;
    cout<<"                                |         |    |     |    |                                           "<<endl;
    cout<<"                                |         |    |_____|____|                                           "<<endl;

}void Load4()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"            ______      _____    _________                                                            "<<endl;
    cout<<"           |           |             |                                                                "<<endl;
    cout<<"           |    __     |_____        |                                                                "<<endl;
    cout<<"           |      |    |             |                                                                "<<endl;
    cout<<"           |______|    |_____        |                                                                "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                 _________                                                            "<<endl;
    cout<<"                                |         |                                                           "<<endl;
    cout<<"                                |_________|                                                           "<<endl;
    cout<<"                                |         |                                                           "<<endl;
    cout<<"                                |         |                                                           "<<endl;
    cout<<"                                |         |                                                           "<<endl;

}void Load3()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"            ______      _____    _________                                                            "<<endl;
    cout<<"           |           |             |                                                                "<<endl;
    cout<<"           |    __     |_____        |                                                                "<<endl;
    cout<<"           |      |    |             |                                                                "<<endl;
    cout<<"           |______|    |_____        |                                                                "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;

}void Load2()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"            ______      _____                                                                         "<<endl;
    cout<<"           |           |                                                                              "<<endl;
    cout<<"           |    __     |_____                                                                         "<<endl;
    cout<<"           |      |    |                                                                              "<<endl;
    cout<<"           |______|    |_____                                                                         "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;

}void Load1()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"            ______                                                                                    "<<endl;
    cout<<"           |                                                                                          "<<endl;
    cout<<"           |    __                                                                                    "<<endl;
    cout<<"           |      |                                                                                   "<<endl;
    cout<<"           |______|                                                                                   "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;

}
void Load0()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;

}

void load()
{
    Load0();
    Sleep(80);
    system("cls");
    Load1();
    Sleep(80);
    system("cls");
    Load2();
    Sleep(80);
    system("cls");
    Load3();
    Sleep(80);
    system("cls");
    Load4();
    Sleep(80);
    system("cls");
    Load5();
    Sleep(80);
    system("cls");
    Load6();
    Sleep(80);
    system("cls");
    Load7();
    Sleep(80);
    system("cls");
    Load8();
    Sleep(80);
    system("cls");
}
