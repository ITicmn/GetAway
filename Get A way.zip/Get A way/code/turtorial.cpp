#include <iostream>
#include <math.h>
#include <cmath>
#include <windows.h>

using namespace std;

int tur1()
{
    char bg[12][22];
    int i,j;
    int g1,g2,f1,f2;
    int e1[2],e2[2],n;
    srand(time(NULL)+getpid());
    start:
    system("cls");
    for (i=0;i<12;i++)
    {
        for (j=0;j<22;j++)
        {
            if (i==0&&j!=0||i==0&&j!=21)
            {
                bg[i][j]=95;
            }
            else if (i!=0&&j==0||i!=0&&j==21)
            {
                bg[i][j]=124;
            }
            else if (i==11&&j!=0||i==11&&j!=21)
            {
                bg[i][j]=95;
            }
            else if (i!=0&&i!=11&&j!=0&&j!=21||i==0&&j==0||i==0&&j==21)
            {
                bg[i][j]=32;
            }
        }
    }
    for (i=0;i<2;i++)
    {
        roll:
        e1[i]=rand()%(12-1)+1;
        for (j=0;j<i;j++)
        {
            if (e1[i]==e1[j])
            {
                goto roll;
            }
        }
        e2[i]=rand()%(21-1)+1;
        for (j=0;j<i;j++)
        {
            if (e2[i]==e2[j])
            {
                goto roll;
            }
        }
        bg[e1[i]][e2[i]]=36;
    }
    g1=1;
    g2=1;
    f1=10;
    f2=20;
    bg[g1][g2]=2;
    bg[f1][f2]=88;
    for (i=0;i<12;i++)
    {
        for (j=0;j<22;j++)
        {
            cout<<bg[i][j]<<flush;
        }
        cout<<endl;
    }
    while (1)
    {
        if (bg[g1][g2]==bg[f1][f2])
        {
            system("cls");
        }
        if (GetKeyState(VK_UP) & 0x8000 || GetKeyState('W') & 0x8000)
        {
            system("cls");
            Sleep(100);
            if (bg[g1-1][g2]!=95)
            {
                bg[g1][g2]=32;
                g1=g1-1;
                bg[g1][g2]=2;
                for (i=0;i<12;i++)
                {
                    for (j=0;j<22;j++)
                    {
                        cout<<bg[i][j]<<flush;
                    }
                    cout<<endl;
                }
            }
        }
        else if (GetKeyState(VK_LEFT) & 0x8000 || GetKeyState('A') & 0x8000)
        {
            system("cls");
            Sleep(100);
            if (bg[g1][g2-1]!=124)
            {
                bg[g1][g2]=32;
                g2=g2-1;
                bg[g1][g2]=2;
                for (i=0;i<12;i++)
                {
                    for (j=0;j<22;j++)
                    {
                        cout<<bg[i][j]<<flush;
                    }
                    cout<<endl;
                }
            }
        }
        else if (GetKeyState(VK_DOWN) & 0x8000 || GetKeyState('S') & 0x8000)
        {
            system("cls");
            Sleep(100);
            if (bg[g1+1][g2]!=95)
            {
                bg[g1][g2]=32;
                g1=g1+1;
                bg[g1][g2]=2;
                for (i=0;i<12;i++)
                {
                    for (j=0;j<22;j++)
                    {
                        cout<<bg[i][j]<<flush;
                    }
                    cout<<endl;
                }
            }
        }
        else if (GetKeyState(VK_RIGHT) & 0x8000 || GetKeyState('D') & 0x8000)
        {
            system("cls");
            Sleep(100);
            if (bg[g1][g2+1]!=124)
            {
                bg[g1][g2]=32;
                g2=g2+1;
                bg[g1][g2]=2;
                for (i=0;i<12;i++)
                {
                    for (j=0;j<22;j++)
                    {
                        cout<<bg[i][j]<<flush;
                    }
                    cout<<endl;
                }
            }
        }
        else if (GetKeyState(VK_ESCAPE) & 0x8000)
        {
            Sleep(100);
            return 0;
        }

    }
    return 0;
}







int tur2()
{
    char bg[12][22];
    int i,j;
    int g1,g2,f1,f2;
    int e1[2],e2[2],n;
    srand(time(NULL)+getpid());
    start:
    system("cls");
    for (i=0;i<12;i++)
    {
        for (j=0;j<22;j++)
        {
            if (i==0&&j!=0||i==0&&j!=21)
            {
                bg[i][j]=95;
            }
            else if (i!=0&&j==0||i!=0&&j==21)
            {
                bg[i][j]=124;
            }
            else if (i==11&&j!=0||i==11&&j!=21)
            {
                bg[i][j]=95;
            }
            else if (i!=0&&i!=11&&j!=0&&j!=21||i==0&&j==0||i==0&&j==21)
            {
                bg[i][j]=32;
            }
        }
    }
    for (i=0;i<2;i++)
    {
        roll:
        e1[i]=rand()%(12-1)+1;
        for (j=0;j<i;j++)
        {
            if (e1[i]==e1[j])
            {
                goto roll;
            }
        }
        e2[i]=rand()%(21-1)+1;
        for (j=0;j<i;j++)
        {
            if (e2[i]==e2[j])
            {
                goto roll;
            }
        }
        bg[e1[i]][e2[i]]=36;
    }
    g1=1;
    g2=1;
    f1=10;
    f2=20;
    bg[g1][g2]=64;
    bg[f1][f2]=88;
    for (i=0;i<12;i++)
    {
        for (j=0;j<22;j++)
        {
            cout<<bg[i][j]<<flush;
        }
        cout<<endl;
    }
    while (1)
    {
        if (bg[g1][g2]==bg[f1][f2])
        {
            system("cls");
            comp();
        }
        for (i=0;i<2;i++)
        {
            if (bg[g1][g2]==bg[e1[i]][e2[i]])
            {
                fail(1);
                goto start;
            }
        }
        if (GetKeyState(VK_UP) & 0x8000 || GetKeyState('W') & 0x8000)
        {
            system("cls");
            Sleep(100);
            if (bg[g1-1][g2]!=95)
            {
                bg[g1][g2]=32;
                g1=g1-1;
                bg[g1][g2]=64;
            }
            for (i=0;i<2;i++)
            {
                if (bg[g1][g2]==bg[e1[i]][e2[i]])
                {
                    fail(1);
                    goto start;
                }
            }
            for (i=0;i<2;i++)
            {
                rand1:
                n=rand()%(5-1)+1;
                if (n==1)
                {
                    if (bg[e1[i]-1][e2[i]]!=95)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e1[i]=e1[i]-1;
                        bg[e1[i]][e2[i]]=36;
                    }
                    else
                    {
                        goto rand1;
                    }
                }
                else if (n==2)
                {
                    if (bg[e1[i]+1][e2[i]]!=95)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e1[i]=e1[i]+1;
                        bg[e1[i]][e2[i]]=36;
                    }
                    else
                    {
                        goto rand1;
                    }
                }
                else if (n==3)
                {
                    if (bg[e1[i]][e2[i]+1]!=124)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e2[i]=e2[i]+1;
                        bg[e1[i]][e2[i]]=36;
                    }
                    else
                    {
                        goto rand1;
                    }
                }
                else if (n==4)
                {
                    if (bg[e1[i]][e2[i]-1]!=124)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e2[i]=e2[i]-1;
                        bg[e1[i]][e2[i]]=36;
                    }
                    else
                    {
                        goto rand1;
                    }
                }
            }
            for (i=0;i<12;i++)
            {
                for (j=0;j<22;j++)
                {
                    cout<<bg[i][j]<<flush;
                }
                cout<<endl;
            }
        }
        else if (GetKeyState(VK_LEFT) & 0x8000 || GetKeyState('A') & 0x8000)
        {
            system("cls");
            Sleep(100);
            if (bg[g1][g2-1]!=124)
            {
                bg[g1][g2]=32;
                g2=g2-1;
                bg[g1][g2]=64;
            }
            for (i=0;i<2;i++)
            {
                if (bg[g1][g2]==bg[e1[i]][e2[i]])
                {
                    fail(1);
                    goto start;
                }
            }
            for (i=0;i<2;i++)
            {
                rand3:
                n=rand()%(5-1)+1;
                if (n==1)
                {
                    if (bg[e1[i]-1][e2[i]]!=95)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e1[i]=e1[i]-1;
                        bg[e1[i]][e2[i]]=36;
                    }
                    else
                    {
                        goto rand3;
                    }
                }
                else if (n==2)
                {
                    if (bg[e1[i]+1][e2[i]]!=95)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e1[i]=e1[i]+1;
                        bg[e1[i]][e2[i]]=36;
                    }
                    else
                    {
                        goto rand3;
                    }
                }
                else if (n==3)
                {
                    if (bg[e1[i]][e2[i]+1]!=124)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e2[i]=e2[i]+1;
                        bg[e1[i]][e2[i]]=36;
                    }
                    else
                    {
                        goto rand3;
                    }
                }
                else if (n==4)
                {
                    if (bg[e1[i]][e2[i]-1]!=124)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e2[i]=e2[i]-1;
                        bg[e1[i]][e2[i]]=36;
                    }
                    else
                    {
                        goto rand3;
                    }
                }
            }
            for (i=0;i<12;i++)
            {
                for (j=0;j<22;j++)
                {
                    cout<<bg[i][j]<<flush;
                }
                cout<<endl;
            }
        }
        else if (GetKeyState(VK_DOWN) & 0x8000 || GetKeyState('S') & 0x8000)
        {
            system("cls");
            Sleep(100);
            if (bg[g1+1][g2]!=95)
            {
                bg[g1][g2]=32;
                g1=g1+1;
                bg[g1][g2]=64;
            }
            for (i=0;i<2;i++)
            {
                if (bg[g1][g2]==bg[e1[i]][e2[i]])
                {
                    fail(1);
                    goto start;
                }
            }
            for (i=0;i<2;i++)
            {
                rand2:
                n=rand()%(5-1)+1;
                if (n==1)
                {
                    if (bg[e1[i]-1][e2[i]]!=95)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e1[i]=e1[i]-1;
                        bg[e1[i]][e2[i]]=36;
                    }
                    else
                    {
                        goto rand2;
                    }
                }
                else if (n==2)
                {
                    if (bg[e1[i]+1][e2[i]]!=95)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e1[i]=e1[i]+1;
                        bg[e1[i]][e2[i]]=36;
                    }
                    else
                    {
                        goto rand2;
                    }
                }
                else if (n==3)
                {
                    if (bg[e1[i]][e2[i]+1]!=124)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e2[i]=e2[i]+1;
                        bg[e1[i]][e2[i]]=36;
                    }
                    else
                    {
                        goto rand2;
                    }
                }
                else if (n==4)
                {
                    if (bg[e1[i]][e2[i]-1]!=124)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e2[i]=e2[i]-1;
                        bg[e1[i]][e2[i]]=36;
                    }
                    else
                    {
                        goto rand2;
                    }
                }
            }
            for (i=0;i<12;i++)
            {
                for (j=0;j<22;j++)
                {
                    cout<<bg[i][j]<<flush;
                }
                cout<<endl;
            }
        }
        else if (GetKeyState(VK_RIGHT) & 0x8000 || GetKeyState('D') & 0x8000)
        {
            system("cls");
            Sleep(100);
            if (bg[g1][g2+1]!=124)
            {
                bg[g1][g2]=32;
                g2=g2+1;
                bg[g1][g2]=64;
            }
            for (i=0;i<2;i++)
            {
                if (bg[g1][g2]==bg[e1[i]][e2[i]])
                {
                    fail(1);
                    goto start;
                }
            }
            for (i=0;i<2;i++)
            {
                rand4:
                n=rand()%(5-1)+1;
                if (n==1)
                {
                    if (bg[e1[i]-1][e2[i]]!=95)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e1[i]=e1[i]-1;
                        bg[e1[i]][e2[i]]=36;
                    }
                    else
                    {
                        goto rand4;
                    }
                }
                else if (n==2)
                {
                    if (bg[e1[i]+1][e2[i]]!=95)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e1[i]=e1[i]+1;
                        bg[e1[i]][e2[i]]=36;
                    }
                    else
                    {
                        goto rand4;
                    }
                }
                else if (n==3)
                {
                    if (bg[e1[i]][e2[i]+1]!=124)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e2[i]=e2[i]+1;
                        bg[e1[i]][e2[i]]=36;
                    }
                    else
                    {
                        goto rand4;
                    }
                }
                else if (n==4)
                {
                    if (bg[e1[i]][e2[i]-1]!=124)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e2[i]=e2[i]-1;
                        bg[e1[i]][e2[i]]=36;
                    }
                    else
                    {
                        goto rand4;
                    }
                }
            }
            for (i=0;i<12;i++)
            {
                for (j=0;j<22;j++)
                {
                    cout<<bg[i][j]<<flush;
                }
                cout<<endl;
            }
        }
        else if (GetKeyState(VK_ESCAPE) & 0x8000)
        {
            Sleep(100);
            return 0;
        }
    }
    return 0;
}
