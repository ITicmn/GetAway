#include <iostream>
#include <math.h>
#include <cmath>
#include <windows.h>

using namespace std;

void level1()
{
    cout<<"Use UP & DOWN key to choose the level:                                                                "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"        *1.  Level 1                                                                                  "<<endl;
    cout<<"         2.  Level 2                                                                                  "<<endl;
    cout<<"         3.  Level 3                                                                                  "<<endl;
    cout<<"         4.  Level 4                                                                                  "<<endl;
    cout<<"         5.  Level 5                                                                                  "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;



}

void level2()
{
    cout<<"Use UP & DOWN key to choose the level:                                                                "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"         1.  Level 1                                                                                  "<<endl;
    cout<<"        *2.  Level 2                                                                                  "<<endl;
    cout<<"         3.  Level 3                                                                                  "<<endl;
    cout<<"         4.  Level 4                                                                                  "<<endl;
    cout<<"         5.  Level 5                                                                                  "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;



}

void level3()
{
    cout<<"Use UP & DOWN key to choose the level:                                                                "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"         1.  Level 1                                                                                  "<<endl;
    cout<<"         2.  Level 2                                                                                  "<<endl;
    cout<<"        *3.  Level 3                                                                                  "<<endl;
    cout<<"         4.  Level 4                                                                                  "<<endl;
    cout<<"         5.  Level 5                                                                                  "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;



}

void level4()
{
    cout<<"Use UP & DOWN key to choose the level:                                                                "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"         1.  Level 1                                                                                  "<<endl;
    cout<<"         2.  Level 2                                                                                  "<<endl;
    cout<<"         3.  Level 3                                                                                  "<<endl;
    cout<<"        *4.  Level 4                                                                                  "<<endl;
    cout<<"         5.  Level 5                                                                                  "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;



}

void level5()
{
    cout<<"Use UP & DOWN key to choose the level:                                                                "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"         1.  Level 1                                                                                  "<<endl;
    cout<<"         2.  Level 2                                                                                  "<<endl;
    cout<<"         3.  Level 3                                                                                  "<<endl;
    cout<<"         4.  Level 4                                                                                  "<<endl;
    cout<<"        *5.  Level 5                                                                                  "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;



}
