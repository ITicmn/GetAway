#include <iostream>
#include <windows.h>
#include <cmath>
#include <math.h>

using namespace std;

void fail0()
{
    cout<<"                          __________  ________  _________            |                                "<<endl;
    cout<<"                         |           |        |     |     |          |                                "<<endl;
    cout<<"                         |           |        |     |     |          |                                "<<endl;
    cout<<"                         |__________ |________|     |     |          |                                "<<endl;
    cout<<"                         |           |        |     |     |          |                                "<<endl;
    cout<<"                         |           |        |     |     |          |                                "<<endl;
    cout<<"                         |           |        | ____|____ |________  .                                "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
}
void fail1()
{
    cout<<"                          __________   ________   _________             |                                "<<endl;
    cout<<"                         |            |        |      |      |          |                                "<<endl;
    cout<<"                         |            |        |      |      |          |                                "<<endl;
    cout<<"                         |__________  |________|      |      |          |                                "<<endl;
    cout<<"                         |            |        |      |      |          |                                "<<endl;
    cout<<"                         |            |        |      |      |          |                                "<<endl;
    cout<<"                         |            |        |  ____|____  |________  .                                "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                   _____________________                                              "<<endl;
    cout<<"                                  |                     |                                             "<<endl;
    cout<<"                                  |       *Retry        |                                             "<<endl;
    cout<<"                                  |_____________________|                                             "<<endl;
    cout<<"                                   _____________________                                              "<<endl;
    cout<<"                                  |                     |                                             "<<endl;
    cout<<"                                  |         Exit        |                                             "<<endl;
    cout<<"                                  |_____________________|                                             "<<endl;
}

void fail2()
{
    cout<<"                          __________   ________   _________             |                                "<<endl;
    cout<<"                         |            |        |      |      |          |                                "<<endl;
    cout<<"                         |            |        |      |      |          |                                "<<endl;
    cout<<"                         |__________  |________|      |      |          |                                "<<endl;
    cout<<"                         |            |        |      |      |          |                                "<<endl;
    cout<<"                         |            |        |      |      |          |                                "<<endl;
    cout<<"                         |            |        |  ____|____  |________  .                                "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                   _____________________                                              "<<endl;
    cout<<"                                  |                     |                                             "<<endl;
    cout<<"                                  |        Retry        |                                             "<<endl;
    cout<<"                                  |_____________________|                                             "<<endl;
    cout<<"                                   _____________________                                              "<<endl;
    cout<<"                                  |                     |                                             "<<endl;
    cout<<"                                  |       * Exit        |                                             "<<endl;
    cout<<"                                  |_____________________|                                             "<<endl;
}

int fail(int x)
{
    system("cls");
    bool T,X;
    int o;
    T=true;
    fail0();
    Sleep(100);
    system("cls");
    fail1();
    while (1)
    {
        if (GetKeyState(VK_UP) & 0x8000)
        {
            if (X==true)
            {
                Sleep(100);
                X=false;
                system("cls");
                T=true;
                fail1();
            }
        }
        else if (GetKeyState(VK_DOWN) & 0x8000)
        {
            if (T==true)
            {
                Sleep(100);
                T=false;
                system("cls");
                X=true;
                fail2();
            }
        }
        else if (GetKeyState(VK_SPACE) & 0x8000)
        {
            if (X==true)
            {
                Sleep(100);
                system("cls");
                return 1;
            }
            else if (T==true)
            {
                Sleep(100);
                system("cls");
                return 0;
            }
        }
    }
}
