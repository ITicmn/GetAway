#include <iostream>
#include <math.h>
#include <cmath>
#include <windows.h>
#include "tur des.cpp"

using namespace std;

void first1()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"                             First in to this game?                                                   "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"           _______________                              _______________                               "<<endl;
    cout<<"          |               |                            |               |                              "<<endl;
    cout<<"          |  *   YES   *  |                            |       NO      |                              "<<endl;
    cout<<"          |_______________|                            |_______________|                              "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                   use LEFT and RIGHT keys to control, SPACE to choose                                "<<endl;
}

void first2()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"                             First in to this game?                                                   "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"           _______________                              _______________                               "<<endl;
    cout<<"          |               |                            |               |                              "<<endl;
    cout<<"          |      YES      |                            |  *    NO    * |                              "<<endl;
    cout<<"          |_______________|                            |_______________|                              "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                   use LEFT and RIGHT keys to control, SPACE to choose                                "<<endl;
}

void second1()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"                             Do you want a Turtorial?                                                 "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"           _______________                              _______________                               "<<endl;
    cout<<"          |               |                            |               |                              "<<endl;
    cout<<"          |  *   YES   *  |                            |       NO      |                              "<<endl;
    cout<<"          |_______________|                            |_______________|                              "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                   use LEFT and RIGHT keys to control, SPACE to choose                                "<<endl;
}

void second2()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"                             Do you want a Turtorial?                                                 "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"           _______________                              _______________                               "<<endl;
    cout<<"          |               |                            |               |                              "<<endl;
    cout<<"          |      YES      |                            |  *    NO    * |                              "<<endl;
    cout<<"          |_______________|                            |_______________|                              "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                   use LEFT and RIGHT keys to control, SPACE to choose                                "<<endl;
}

int choose()
{
    bool Y,N;
    Y=true;
    first1();
    while (1)
    {
        if (GetKeyState(VK_LEFT) & 0x8000)
        {
            if (N==true)
            {
                Sleep(100);
                N=false;
                system("cls");
                first1();
                Y=true;
            }
        }
        else if (GetKeyState(VK_RIGHT) & 0x8000)
        {
            if (Y==true)
            {
                Sleep(100);
                Y=false;
                system("cls");
                first2();
                N=true;
            }
        }
        else if (GetKeyState(VK_SPACE) & 0x8000)
        {
            if (Y==true)
            {
                Sleep(100);
                system("cls");
                break;
            }
            else if (N==true)
            {
                Sleep(100);
                system("cls");
                return 0;
            }
        }

    }
    Y=true;
    second1();
    while (1)
    {
        if (GetKeyState(VK_LEFT) & 0x8000)
        {
            if (N==true)
            {
                Sleep(100);
                N=false;
                system("cls");
                second1();
                Y=true;
            }
        }
        else if (GetKeyState(VK_RIGHT) & 0x8000)
        {
            if (Y==true)
            {
                Sleep(100);
                Y=false;
                system("cls");
                second2();
                N=true;
            }
        }
        else if (GetKeyState(VK_SPACE) & 0x8000)
        {
            if (Y==true)
            {
                Sleep(100);
                system("cls");
                turcon();
                break;
            }
            else if (N==true)
            {
                Sleep(100);
                system("cls");
                break;
            }
        }
    }
}
