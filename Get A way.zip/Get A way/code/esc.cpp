#include <iostream>
#include <math.h>
#include <cmath>
#include <windows.h>
#include "Settings.cpp"

using namespace std;

void esc0()
{
    cout<<"                        ________________________________________                                      "<<endl;
    cout<<"                       |                                        |                                     "<<endl;
    cout<<"                       |               *  Back  *               |                                     "<<endl;
    cout<<"                       |________________________________________|                                     "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                        ________________________________________                                      "<<endl;
    cout<<"                       |                                        |                                     "<<endl;
    cout<<"                       |                Settings                |                                     "<<endl;
    cout<<"                       |________________________________________|                                     "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                        ________________________________________                                      "<<endl;
    cout<<"                       |                                        |                                     "<<endl;
    cout<<"                       |                  Quit                  |                                     "<<endl;
    cout<<"                       |________________________________________|                                     "<<endl;
}

void esc1()
{
    cout<<"                        ________________________________________                                      "<<endl;
    cout<<"                       |                                        |                                     "<<endl;
    cout<<"                       |                  Back                  |                                     "<<endl;
    cout<<"                       |________________________________________|                                     "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                        ________________________________________                                      "<<endl;
    cout<<"                       |                                        |                                     "<<endl;
    cout<<"                       |               *Settings*               |                                     "<<endl;
    cout<<"                       |________________________________________|                                     "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                        ________________________________________                                      "<<endl;
    cout<<"                       |                                        |                                     "<<endl;
    cout<<"                       |                  Quit                  |                                     "<<endl;
    cout<<"                       |________________________________________|                                     "<<endl;
}

void esc2()
{
    cout<<"                        ________________________________________                                      "<<endl;
    cout<<"                       |                                        |                                     "<<endl;
    cout<<"                       |                  Back                  |                                     "<<endl;
    cout<<"                       |________________________________________|                                     "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                        ________________________________________                                      "<<endl;
    cout<<"                       |                                        |                                     "<<endl;
    cout<<"                       |                Settings                |                                     "<<endl;
    cout<<"                       |________________________________________|                                     "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                        ________________________________________                                      "<<endl;
    cout<<"                       |                                        |                                     "<<endl;
    cout<<"                       |               *  Quit  *               |                                     "<<endl;
    cout<<"                       |________________________________________|                                     "<<endl;
}

int esc()
{
    bool Q,S=false,B;
    B=true;
    esc0();
    esc:
    if (S==true)
    {
        esc1();
    }
    while (1)
    {
        if (GetKeyState(VK_UP) & 0x8000)
        {
            if (Q==true)
            {
                Sleep(100);
                Q=false;
                system("cls");
                esc1();
                S=true;
            }
            else if (S==true)
            {
                Sleep(100);
                S=false;
                system("cls");
                esc0();
                B=true;
            }

        }
        else if (GetKeyState(VK_DOWN) & 0x8000)
        {
            if (B==true)
            {
                Sleep(100);
                B=false;
                system("cls");
                esc1();
                S=true;
            }
            else if (S==true)
            {
                Sleep(100);
                S=false;
                system("cls");
                esc2();
                Q=true;
            }
        }
        else if (GetKeyState(VK_SPACE) & 0x8000)
        {
            if (B==true)
            {
                Sleep(100);
                system("cls");
                return 0;
            }
            else if (S==true)
            {
                Sleep(100);
                system("cls");
                sets();
                goto esc;
            }
            else if (Q==true)
            {
                Sleep(100);
                system("cls");
                PostMessage(GetConsoleWindow(),WM_CLOSE,0,0);
            }
        }
    }

}
