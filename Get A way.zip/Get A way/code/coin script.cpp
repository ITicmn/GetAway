#include <iostream>
#include <math.h>
#include <cmath>
#include <windows.h>

using namespace std;
