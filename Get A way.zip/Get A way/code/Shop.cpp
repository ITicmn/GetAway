#include <iostream>
#include <math.h>
#include <cmath>
#include <windows.h>
#include <bits/stdc++.h>

using namespace std;

void shop1()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"            * Misery Effect                                                                           "<<endl;
    cout<<"              Ghost Effect                                                                            "<<endl;
    cout<<"              Damage Effect                                                                           "<<endl;
    cout<<"              Heal Effect                                                                             "<<endl;
    cout<<"                                                                                                      "<<endl;
}

void shop2()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"              Misery Effect                                                                           "<<endl;
    cout<<"            * Ghost Effect                                                                            "<<endl;
    cout<<"              Damage Effect                                                                           "<<endl;
    cout<<"              Heal Effect                                                                             "<<endl;
    cout<<"                                                                                                      "<<endl;
}

void shop3()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"              Misery Effect                                                                           "<<endl;
    cout<<"              Ghost Effect                                                                            "<<endl;
    cout<<"            * Damage Effect                                                                           "<<endl;
    cout<<"              Heal Effect                                                                             "<<endl;
    cout<<"                                                                                                      "<<endl;
}

void shop4()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"              Misery Effect                                                                           "<<endl;
    cout<<"              Ghost Effect                                                                            "<<endl;
    cout<<"              Damage Effect                                                                           "<<endl;
    cout<<"            * Heal Effect                                                                             "<<endl;
    cout<<"                                                                                                      "<<endl;
}

void shop5()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"            * Misery Effect   SOLD                                                                    "<<endl;
    cout<<"              Ghost Effect                                                                            "<<endl;
    cout<<"              Damage Effect                                                                           "<<endl;
    cout<<"              Heal Effect                                                                             "<<endl;
    cout<<"                                                                                                      "<<endl;
}

void shop6()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"              Misery Effect   SOLD                                                                    "<<endl;
    cout<<"            * Ghost Effect                                                                            "<<endl;
    cout<<"              Damage Effect                                                                           "<<endl;
    cout<<"              Heal Effect                                                                             "<<endl;
    cout<<"                                                                                                      "<<endl;
}

void shop7()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"              Misery Effect   SOLD                                                                    "<<endl;
    cout<<"              Ghost Effect                                                                            "<<endl;
    cout<<"            * Damage Effect                                                                           "<<endl;
    cout<<"              Heal Effect                                                                             "<<endl;
    cout<<"                                                                                                      "<<endl;
}

void shop8()
{
    cout<<"                                                                                                      "<<endl;
    cout<<"              Misery Effect   SOLD                                                                    "<<endl;
    cout<<"              Ghost Effect                                                                            "<<endl;
    cout<<"              Damage Effect                                                                           "<<endl;
    cout<<"            * Heal Effect                                                                             "<<endl;
    cout<<"                                                                                                      "<<endl;
}

int shopm()
{
    int mis=0;
    bool M,G,D,H;
    M=true;
    shop1();
    while (1)
    {
        if (GetKeyState(VK_UP) & 0x8000)
        {
            Sleep(100);
            if (H==true)
            {
                system("cls");
                if (mis==1)
                {
                    shop7();
                }
                else
                {
                    shop3();
                }
                H=false;
                D=true;
            }
            else if (D==true)
            {
                system("cls");
                if (mis==1)
                {
                    shop6();
                }
                else
                {
                    shop2();
                }
                D=false;
                G=true;
            }
            else if (G==true)
            {
                system("cls");
                if (mis==1)
                {
                    shop5();
                }
                else
                {
                    shop1();
                }
                G=false;
                M=true;
            }
        }
        else if (GetKeyState(VK_DOWN) & 0x8000)
        {
            Sleep(100);
            if (M==true)
            {
                system("cls");
                if (mis==1)
                {
                    shop6();
                }
                else
                {
                    shop2();
                }
                M=false;
                G=true;
            }
            else if (G==true)
            {
                system("cls");
                if (mis==1)
                {
                    shop7();
                }
                else
                {
                    shop3();
                }
                G=false;
                D=true;
            }
            else if (D==true)
            {
                system("cls");
                if (mis==1)
                {
                    shop8();
                }
                else
                {
                    shop4();
                }
                D=false;
                H=true;
            }
        }
        else if (GetKeyState(VK_SPACE) & 0x8000)
        {
            Sleep(100);
            if (G==true||D==true||H==true)
            {
                cout<<"                           You do not have enough money...                                            "<<endl;
                cout<<"                                                                                                      "<<endl;
                cout<<"                                                                                                      "<<endl;
                cout<<"                                                                                                      "<<endl;
                cout<<"                                                                                                      "<<endl;
                cout<<"                                                                                                      "<<endl;
                Sleep(200);
                system("cls");
                if (G==true)
                {
                    if (mis==1)
                    {
                        shop6();
                    }
                    else
                    {
                        shop2();
                    }
                }
                else if (D==true)
                {
                    if (mis==1)
                    {
                        shop7();
                    }
                    else
                    {
                        shop3();
                    }
                }
                else if (H==true)
                {
                    if (mis==1)
                    {
                        shop8();
                    }
                    else
                    {
                        shop4();
                    }
                }
            }
            else if (M==true&&mis==0)
            {
                mis=1;
                cout<<"                                      Thanks                                                          "<<endl;
                cout<<"                                                                                                      "<<endl;
                cout<<"                                                                                                      "<<endl;
                cout<<"                                                                                                      "<<endl;
                cout<<"                                                                                                      "<<endl;
                cout<<"                                                                                                      "<<endl;
                Sleep(200);
                system("cls");
                if (mis==1)
                {
                    shop5();
                }
                else
                {
                    shop1();
                }
            }
            else if (M==true&&mis==1)
            {
                cout<<"                                    It is sold out                                                    "<<endl;
                cout<<"                                                                                                      "<<endl;
                cout<<"                                                                                                      "<<endl;
                cout<<"                                                                                                      "<<endl;
                cout<<"                                                                                                      "<<endl;
                cout<<"                                                                                                      "<<endl;
                Sleep(200);
                system("cls");
                shop5();
            }
        }
        else if (GetKeyState(VK_ESCAPE) & 0x8000)
        {
            system("cls");
            if (mis==0)
            {
                return 0;
            }
            else if (mis==1)
            {
                return 1;
            }
        }
    }
}
