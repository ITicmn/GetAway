#include <iostream>
#include <windows.h>
#include <cmath>
#include <math.h>

using namespace std;

void com0()
{
    cout<<"                            __  __   _ _   _       __ ___  __    |                                    "<<endl;
    cout<<"                           |   |  | | | | |_| |   |__  |  |__    |                                    "<<endl;
    cout<<"                           |__ |__| | | | |   |__ |__  |  |__    .                                    "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
}

void com1()
{
    cout<<"                            __  __   _ _   _       __ ___  __    |                                    "<<endl;
    cout<<"                           |   |  | | | | |_| |   |__  |  |__    |                                    "<<endl;
    cout<<"                           |__ |__| | | | |   |__ |__  |  |__    .                                    "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                   _____________________                                              "<<endl;
    cout<<"                                  |                     |                                             "<<endl;
    cout<<"                                  |     *CONTINUE       |                                             "<<endl;
    cout<<"                                  |_____________________|                                             "<<endl;
    cout<<"                                   _____________________                                              "<<endl;
    cout<<"                                  |                     |                                             "<<endl;
    cout<<"                                  |        Retry        |                                             "<<endl;
    cout<<"                                  |_____________________|                                             "<<endl;
    cout<<"                                   _____________________                                              "<<endl;
    cout<<"                                  |                     |                                             "<<endl;
    cout<<"                                  |         Exit        |                                             "<<endl;
    cout<<"                                  |_____________________|                                             "<<endl;
}

void com2()
{
    cout<<"                            __  __   _ _   _       __ ___  __    |                                    "<<endl;
    cout<<"                           |   |  | | | | |_| |   |__  |  |__    |                                    "<<endl;
    cout<<"                           |__ |__| | | | |   |__ |__  |  |__    .                                    "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                   _____________________                                              "<<endl;
    cout<<"                                  |                     |                                             "<<endl;
    cout<<"                                  |      CONTINUE       |                                             "<<endl;
    cout<<"                                  |_____________________|                                             "<<endl;
    cout<<"                                   _____________________                                              "<<endl;
    cout<<"                                  |                     |                                             "<<endl;
    cout<<"                                  |     *  Retry        |                                             "<<endl;
    cout<<"                                  |_____________________|                                             "<<endl;
    cout<<"                                   _____________________                                              "<<endl;
    cout<<"                                  |                     |                                             "<<endl;
    cout<<"                                  |         Exit        |                                             "<<endl;
    cout<<"                                  |_____________________|                                             "<<endl;
}

void com3()
{
    cout<<"                            __  __   _ _   _       __ ___  __    |                                    "<<endl;
    cout<<"                           |   |  | | | | |_| |   |__  |  |__    |                                    "<<endl;
    cout<<"                           |__ |__| | | | |   |__ |__  |  |__    .                                    "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                   _____________________                                              "<<endl;
    cout<<"                                  |                     |                                             "<<endl;
    cout<<"                                  |      CONTINUE       |                                             "<<endl;
    cout<<"                                  |_____________________|                                             "<<endl;
    cout<<"                                   _____________________                                              "<<endl;
    cout<<"                                  |                     |                                             "<<endl;
    cout<<"                                  |        Retry        |                                             "<<endl;
    cout<<"                                  |_____________________|                                             "<<endl;
    cout<<"                                   _____________________                                              "<<endl;
    cout<<"                                  |                     |                                             "<<endl;
    cout<<"                                  |     *   Exit        |                                             "<<endl;
    cout<<"                                  |_____________________|                                             "<<endl;
}

int comp()
{
    bool C,R,E;
    C=true;
    com0();
    Sleep(100);
    system("cls");
    com1();
    while (1)
    {
        if (GetKeyState(VK_UP) & 0x8000)
        {
            if (E==true)
            {
                Sleep(100);
                E=false;
                system("cls");
                com2();
                R=true;
            }
            else if (R==true)
            {
                Sleep(100);
                R=false;
                system("cls");
                com1();
                C=true;
            }

        }
        else if (GetKeyState(VK_DOWN) & 0x8000)
        {
            if (C==true)
            {
                Sleep(100);
                C=false;
                system("cls");
                com2();
                R=true;
            }
            else if (R==true)
            {
                Sleep(100);
                R=false;
                system("cls");
                com3();
                E=true;
            }
        }
        else if (GetKeyState(VK_SPACE) & 0x8000)
        {
            if (E==true)
            {
                Sleep(100);
                system("cls");
                return 0;
            }
            else if (R==true)
            {
                Sleep(100);
                system("cls");
            }
            else if (C==true)
            {
                Sleep(100);
                system("cls");
            }
        }
    }
}
