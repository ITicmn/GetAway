#include <math.h>
#include <cmath>
#include <windows.h>
#include "Level Menu.cpp"
#include "Lv1.cpp"
#include "Lv2.cpp"
#include "Lv3.cpp"
#include "Lv4.cpp"
#include "Lv5.cpp"
#include "esc.cpp"
#include "Loading.cpp"
#include "tur choose.cpp"

using namespace std;

int main()
{
    bool lv1=false,lv2=false,lv3=false,lv4=false,lv5=false;
    cout<<"Welcome to Get A way!"<<endl;
    cout<<"Press SPACE to start"<<endl;
    while (1)
    {
        if (GetKeyState(VK_SPACE) & 0x8000)
        {
            Sleep(100);
            system("cls");
            load();
            Sleep(100);
            choose();
            break;
        }
        else if (GetKeyState(VK_ESCAPE) & 0x8000)
        {
            system("cls");
            return 0;
        }
    }
    lv1=true;
    Menu:
    system("cls");
    if (lv1==true)
    {
        level1();
    }
    else if (lv2==true)
    {
        level2();
    }
    else if (lv3==true)
    {
        level3();
    }
    else if (lv4==true)
    {
        level4();
    }
    else if (lv5==true)
    {
        level5();
    }
    while (1)
    {
        if (GetKeyState(VK_UP) & 0x8000)
        {
            Sleep(100);
            if (lv5==true)
            {
                lv5=false;
                system("cls");
                level4();
                lv4=true;
            }
            else if (lv4==true)
            {
                lv4=false;
                system("cls");
                level3();
                lv3=true;
            }
            else if (lv3==true)
            {
                lv3=false;
                system("cls");
                level2();
                lv2=true;
            }
            else if (lv2==true)
            {
                lv2=false;
                system("cls");
                level1();
                lv1=true;
            }
        }
        else if (GetKeyState(VK_DOWN) & 0x8000)
        {
            Sleep(100);
            if (lv1==true)
            {
                lv1=false;
                system("cls");
                level2();
                lv2=true;
            }
            else if (lv2==true)
            {
                lv2=false;
                system("cls");
                level3();
                lv3=true;
            }
            else if (lv3==true)
            {
                lv3=false;
                system("cls");
                level4();
                lv4=true;
            }
            else if (lv4==true)
            {
                lv4=false;
                system("cls");
                level5();
                lv5=true;
            }
        }
        else if (GetKeyState(VK_SPACE) & 0x8000)
        {
            if (lv1==true)
            {
                load();
                if (Lev1()==1)
                {
                    load();
                    if (Lev2()==1)
                    {
                        load();
                        if (Lev3()==1)
                        {
                            load();
                            if (Lev4()==1)
                            {
                                load();
                                if (Lev5()==1)
                                {
                                    cout<<"There's no more levels"<<endl;
                                    Sleep(500);
                                    system("cls");
                                    break;
                                }
                            }
                        }
                    }
                }
                break;
            }
            else if (lv2==true)
            {
                load();
                if (Lev2()==1)
                {
                    load();
                    if (Lev3()==1)
                    {
                        load();
                        if (Lev4()==1)
                        {
                            if (Lev5()==1)
                            {
                                cout<<"There's no more levels"<<endl;
                                Sleep(500);
                                system("cls");
                                break;
                            }
                        }
                    }
                }
                break;
            }
            else if (lv3==true)
            {
                load();
                if (Lev3()==1)
                {
                    load();
                    if (Lev4()==1)
                    {
                        load();
                        if (Lev5()==1)
                        {
                            cout<<"There's no more levels"<<endl;
                            Sleep(500);
                            system("cls");
                            break;
                        }
                    }
                }
                break;
            }
            else if (lv4==true)
            {
                load();
                if (Lev4()==1)
                {
                    load();
                    if (Lev5()==1)
                    {
                        cout<<"There's no more levels"<<endl;
                        Sleep(500);
                        system("cls");
                        break;
                    }
                }
                break;
            }
            else if (lv5==true)
            {
                load();
                Lev5();
                break;
            }
        }
        else if (GetKeyState(VK_ESCAPE) & 0x8000)
        {
            Sleep(100);
            system("cls");
            esc();
            break;
        }
    }
    goto Menu;






    return 0;
}
