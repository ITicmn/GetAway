#include <iostream>
#include <math.h>
#include <cmath>
#include <windows.h>

using namespace std;

int Lev2()
{
    start:
    char bg[14][24];
    int i,j;
    int g1,g2,f1,f2;
    int e1[4],e2[4],n,buff=0,t=0;
    srand(time(NULL)+getpid());
    system("cls");
    for (i=0;i<14;i++)
    {
        for (j=0;j<24;j++)
        {
            if (i==0&&j!=0||i==0&&j!=23)
            {
                bg[i][j]=95;
            }
            else if (i!=0&&j==0||i!=0&&j==23)
            {
                bg[i][j]=179;
            }
            else if (i==13&&j!=0||i==13&&j!=23)
            {
                bg[i][j]=95;
            }
            else if (i!=0&&i!=13&&j!=0&&j!=23||i==0&&j==0||i==0&&j==23)
            {
                bg[i][j]=32;
            }
        }
    }
    for (i=1;i<14;i++)
    {
        for (j=1;j<24;j++)
        {
            if (j==11&&i<=7)
            {
                bg[i][j]=219;
            }
            else if (j==18&&i>=5)
            {
                bg[i][j]=219;
            }
            else if (j==6&&i>=5)
            {
                bg[i][j]=219;
            }
        }
    }
    g1=1;
    g2=1;
    f1=12;
    f2=22;
    bg[g1][g2]=2;
    bg[f1][f2]=88;
    for (i=0;i<4;i++)
    {
        roll:
        e1[i]=rand()%(13-1)+1;
        for (j=0;j<i;j++)
        {
            if (e1[i]==e1[j])
            {
                goto roll;
            }
        }
        e2[i]=rand()%(23-1)+1;
        for (j=0;j<i;j++)
        {
            if (e2[i]==e2[j])
            {
                goto roll;
            }
        }
        if (bg[e1[i]][e2[i]]!=32)
        {
            goto roll;
        }
        bg[e1[i]][e2[i]]=1;
    }
    for (i=0;i<14;i++)
    {
        for (j=0;j<24;j++)
        {
            cout<<bg[i][j]<<flush;
        }
        cout<<endl;
    }
    while (1)
    {
        if (bg[g1][g2]==bg[f1][f2])
        {
            system("cls");
            goto complete;
        }
        for (i=0;i<4;i++)
        {
            if (bg[g1][g2]==bg[e1[i]][e2[i]])
            {
                goto fail;
            }
        }
        if (GetKeyState(VK_UP) & 0x8000 || GetKeyState('W') & 0x8000)
        {
            system("cls");
            Sleep(100);
            if (bg[g1-1][g2]==32||bg[g1-1][g2]==88)
            {
                bg[g1][g2]=32;
                g1=g1-1;
                bg[g1][g2]=2;
            }
            else if (bg[g1-1][g2]==1)
            {
                if (buff==4)
                {
                    t=t+1;
                }
                else if (buff!=4||buff==4&&t>3)
                {
                    goto fail;
                }
            }
            for (i=0;i<4;i++)
            {
                rand1:
                n=rand()%(5-1)+1;
                if (n==1)
                {
                    if (bg[e1[i]-1][e2[i]]==32)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e1[i]=e1[i]-1;
                        bg[e1[i]][e2[i]]=1;
                    }
                    else
                    {
                        goto rand1;
                    }
                }
                else if (n==2)
                {
                    if (bg[e1[i]+1][e2[i]]==32)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e1[i]=e1[i]+1;
                        bg[e1[i]][e2[i]]=1;
                    }
                    else
                    {
                        goto rand1;
                    }
                }
                else if (n==3)
                {
                    if (bg[e1[i]][e2[i]+1]==32)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e2[i]=e2[i]+1;
                        bg[e1[i]][e2[i]]=1;
                    }
                    else
                    {
                        goto rand1;
                    }
                }
                else if (n==4)
                {
                    if (bg[e1[i]][e2[i]-1]==32)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e2[i]=e2[i]-1;
                        bg[e1[i]][e2[i]]=1;
                    }
                    else
                    {
                        goto rand1;
                    }
                }
            }
            for (i=0;i<14;i++)
            {
                for (j=0;j<24;j++)
                {
                    cout<<bg[i][j]<<flush;
                }
                cout<<endl;
            }
        }
        else if (GetKeyState(VK_LEFT) & 0x8000 || GetKeyState('A') & 0x8000)
        {
            system("cls");
            Sleep(100);
            if (bg[g1][g2-1]==32||bg[g1][g2-1]==88)
            {
                bg[g1][g2]=32;
                g2=g2-1;
                bg[g1][g2]=2;
            }
            else if (bg[g1][g2-1]==1)
            {
                if (buff==4)
                {
                    t=t+1;
                }
                else if (buff!=4||buff==4&&t>3)
                {
                    goto fail;
                }
            }
            for (i=0;i<4;i++)
            {
                rand3:
                n=rand()%(5-1)+1;
                if (n==1)
                {
                    if (bg[e1[i]-1][e2[i]]==32)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e1[i]=e1[i]-1;
                        bg[e1[i]][e2[i]]=1;
                    }
                    else
                    {
                        goto rand3;
                    }
                }
                else if (n==2)
                {
                    if (bg[e1[i]+1][e2[i]]==32)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e1[i]=e1[i]+1;
                        bg[e1[i]][e2[i]]=1;
                    }
                    else
                    {
                        goto rand3;
                    }
                }
                else if (n==3)
                {
                    if (bg[e1[i]][e2[i]+1]==32)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e2[i]=e2[i]+1;
                        bg[e1[i]][e2[i]]=1;
                    }
                    else
                    {
                        goto rand3;
                    }
                }
                else if (n==4)
                {
                    if (bg[e1[i]][e2[i]-1]==32)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e2[i]=e2[i]-1;
                        bg[e1[i]][e2[i]]=1;
                    }
                    else
                    {
                        goto rand3;
                    }
                }
            }
            for (i=0;i<14;i++)
            {
                for (j=0;j<24;j++)
                {
                    cout<<bg[i][j]<<flush;
                }
                cout<<endl;
            }
        }
        else if (GetKeyState(VK_DOWN) & 0x8000 || GetKeyState('S') & 0x8000)
        {
            system("cls");
            Sleep(100);
            if (bg[g1+1][g2]==32||bg[g1+1][g2]==88)
            {
                bg[g1][g2]=32;
                g1=g1+1;
                bg[g1][g2]=2;
            }
            else if (bg[g1+1][g2]==1)
            {
                if (buff==4)
                {
                    t=t+1;
                }
                else if (buff!=4||buff==4&&t>3)
                {
                    goto fail;
                }
            }
            for (i=0;i<4;i++)
            {
                rand2:
                n=rand()%(5-1)+1;
                if (n==1)
                {
                    if (bg[e1[i]-1][e2[i]]==32)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e1[i]=e1[i]-1;
                        bg[e1[i]][e2[i]]=1;
                    }
                    else
                    {
                        goto rand2;
                    }
                }
                else if (n==2)
                {
                    if (bg[e1[i]+1][e2[i]]==32)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e1[i]=e1[i]+1;
                        bg[e1[i]][e2[i]]=1;
                    }
                    else
                    {
                        goto rand2;
                    }
                }
                else if (n==3)
                {
                    if (bg[e1[i]][e2[i]+1]==32)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e2[i]=e2[i]+1;
                        bg[e1[i]][e2[i]]=1;
                    }
                    else
                    {
                        goto rand2;
                    }
                }
                else if (n==4)
                {
                    if (bg[e1[i]][e2[i]-1]==32)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e2[i]=e2[i]-1;
                        bg[e1[i]][e2[i]]=1;
                    }
                    else
                    {
                        goto rand2;
                    }
                }
            }
            for (i=0;i<14;i++)
            {
                for (j=0;j<24;j++)
                {
                    cout<<bg[i][j]<<flush;
                }
                cout<<endl;
            }
        }
        else if (GetKeyState(VK_RIGHT) & 0x8000 || GetKeyState('D') & 0x8000)
        {
            system("cls");
            Sleep(100);
            if (bg[g1][g2+1]==32||bg[g1][g2+1]==88)
            {
                bg[g1][g2]=32;
                g2=g2+1;
                bg[g1][g2]=2;
            }
            else if (bg[g1][g2+1]==1)
            {
                if (buff==4)
                {
                    t=t+1;
                }
                else if (buff!=4||buff==4&&t>3)
                {
                    goto fail;
                }
            }
            for (i=0;i<4;i++)
            {
                rand4:
                n=rand()%(5-1)+1;
                if (n==1)
                {
                    if (bg[e1[i]-1][e2[i]]==32)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e1[i]=e1[i]-1;
                        bg[e1[i]][e2[i]]=1;
                    }
                    else
                    {
                        goto rand4;
                    }
                }
                else if (n==2)
                {
                    if (bg[e1[i]+1][e2[i]]==32)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e1[i]=e1[i]+1;
                        bg[e1[i]][e2[i]]=1;
                    }
                    else
                    {
                        goto rand4;
                    }
                }
                else if (n==3)
                {
                    if (bg[e1[i]][e2[i]+1]==32)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e2[i]=e2[i]+1;
                        bg[e1[i]][e2[i]]=1;
                    }
                    else
                    {
                        goto rand4;
                    }
                }
                else if (n==4)
                {
                    if (bg[e1[i]][e2[i]-1]==32)
                    {
                        bg[e1[i]][e2[i]]=32;
                        e2[i]=e2[i]-1;
                        bg[e1[i]][e2[i]]=1;
                    }
                    else
                    {
                        goto rand4;
                    }
                }
            }
            for (i=0;i<14;i++)
            {
                for (j=0;j<24;j++)
                {
                    cout<<bg[i][j]<<flush;
                }
                cout<<endl;
            }
        }
        else if (GetKeyState(VK_ESCAPE) & 0x8000)
        {
            Sleep(100);
            return 0;
        }
    }
    fail:
    system("cls");
    bool T,X;
    int o;
    T=true;
    fail0();
    Sleep(100);
    system("cls");
    fail1();
    while (1)
    {
        if (GetKeyState(VK_UP) & 0x8000)
        {
            if (X==true)
            {
                Sleep(100);
                X=false;
                system("cls");
                T=true;
                fail1();
            }
        }
        else if (GetKeyState(VK_DOWN) & 0x8000)
        {
            if (T==true)
            {
                Sleep(100);
                T=false;
                system("cls");
                X=true;
                fail2();
            }
        }
        else if (GetKeyState(VK_SPACE) & 0x8000)
        {
            if (X==true)
            {
                Sleep(100);
                system("cls");
                return 0;
            }
            else if (T==true)
            {
                Sleep(100);
                system("cls");
                goto start;
            }
        }
    }
    complete:
    bool C,R,E;
    C=true;
    com0();
    Sleep(100);
    system("cls");
    com1();
    while (1)
    {
        if (GetKeyState(VK_UP) & 0x8000)
        {
            if (E==true)
            {
                Sleep(100);
                E=false;
                system("cls");
                com2();
                R=true;
            }
            else if (R==true)
            {
                Sleep(100);
                R=false;
                system("cls");
                com1();
                C=true;
            }

        }
        else if (GetKeyState(VK_DOWN) & 0x8000)
        {
            if (C==true)
            {
                Sleep(100);
                C=false;
                system("cls");
                com2();
                R=true;
            }
            else if (R==true)
            {
                Sleep(100);
                R=false;
                system("cls");
                com3();
                E=true;
            }
        }
        else if (GetKeyState(VK_SPACE) & 0x8000)
        {
            if (E==true)
            {
                Sleep(100);
                system("cls");
                return 0;
            }
            else if (R==true)
            {
                Sleep(100);
                system("cls");
                goto start;
            }
            else if (C==true)
            {
                Sleep(100);
                system("cls");
                return 1;
            }
        }
    }
}
