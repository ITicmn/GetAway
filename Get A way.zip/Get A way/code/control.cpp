#include <iostream>
#include <math.h>
#include <cmath>
#include <windows.h>

using namespace std;

void con0()
{
    char a[12]={2,1,0,0,88,3,4,5,6,124,95,0};
    a[2]=45;
    a[3]=30;
    a[11]=219;
    cout<<" <ESC                                      CONTROL                                                    "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                ________                                                                              "<<endl;
    cout<<"               |        |                  SPACE:Select                                               "<<endl;
    cout<<"               |  W/UP  |                  ESC:PAUSE/QUIT                                             "<<endl;
    cout<<"               |________|                  Player --> "<<a[0]<<endl;//2
    cout<<"      ________  ________  ________         Enemy --> "<<a[1]<<endl;//1
    cout<<"     |        ||        ||        |        Spike(Safe) --> "<<a[2]<<endl;//45
    cout<<"     | A/LEFT || S/DOWN || D/RIGHT|        Spike(Unsafe) --> "<<a[3]<<endl;//30
    cout<<"     |________||________||________|        Goal --> "<<a[4]<<endl;//88
    cout<<"                                           Buff --> "<<a[5]<<","<<a[6]<<","<<a[7]<<","<<a[8]<<endl;//3,4,5,6
    cout<<"                                           Walls --> "<<a[9]<<","<<a[10]<<","<<a[11]<<endl;//124,95,219
    cout<<"                                                                                                      "<<endl;
}

int con()
{
    system("cls");
    con0();
    while (1)
    {
        if (GetKeyState(VK_ESCAPE) & 0x8000)
        {
            Sleep(100);
            system("cls");
            return 0;
        }
    }
}
