#include <iostream>
#include <math.h>
#include <cmath>
#include <windows.h>

using namespace std;

void turcon0()
{
    cout<<" <ESC                                      CONTROL                                                    "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                ________                                                                              "<<endl;
    cout<<"               |        |                  SPACE:Select                                               "<<endl;
    cout<<"               |  W/UP  |                  ESC:PAUSE/QUIT                                             "<<endl;
    cout<<"               |________|                                                                             "<<endl;
    cout<<"      ________  ________  ________                                                                    "<<endl;
    cout<<"     |        ||        ||        |                                                                   "<<endl;
    cout<<"     | A/LEFT || S/DOWN || D/RIGHT|                                                                   "<<endl;
    cout<<"     |________||________||________|                                                                   "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                                                      "<<endl;
    cout<<"                                                                             Press SPACE to continue> "<<endl;
}

int turcon()
{
    turcon0();
    while (1)
    {
        if (GetKeyState(VK_ESCAPE) & 0x8000)
        {
            Sleep(100);
            system("cls");
            return 0;
        }
        else if (GetKeyState(VK_SPACE) & 0x8000)
        {
            Sleep(100);
            system("cls");
            tur1();
            return 0;
        }
    }
}
