/*
#ifdef LEVEL_HPP
#define LEVEL_HPP

extern int Lev1();
extern int Lev2();
extern int Lev3();
extern int Lev4();
extern int Lev5();

#endif
*/
